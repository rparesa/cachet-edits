<!DOCTYPE html>
<html>
@include('dashboard.partials.head')

<body class="dashboard @yield('bodyClass')">
    <div class="content">
        @yield('content')
    </div>
</body>
</html>
