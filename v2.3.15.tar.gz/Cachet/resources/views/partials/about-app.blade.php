@if($about_app)
<div class="about-app">
    <h2>{{ trans('cachet.about_this_site') }}</h2>
    {!! $about_app !!}
</div>
@endif

